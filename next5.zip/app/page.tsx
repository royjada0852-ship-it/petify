import Link from "next/link"
import {
  Heart,
  Shield,
  Headphones,
  Award,
  Package,
  Dog,
  ShoppingBag,
  Pill,
  Sparkles,
  Users,
  TrendingUp,
  Clock,
  Apple,
} from "lucide-react"
import { GetHelpForm } from "@/components/get-help-form"
import { IconBadge } from "@/components/icon-badge"
import { CategoryCard } from "@/components/category-card"

export default async function HomePage() {
  return (
    <main className="container mx-auto px-4 pb-12 overflow-x-hidden">
      {/* Hero Section */}
      <section className="hero-section relative z-10">
        <div className="relative z-10 max-w-4xl">
          <h1 className="hero-heading text-4xl md:text-6xl font-extrabold text-white mb-6 leading-tight">
            Find Your Perfect <span className="text-orange-300">Pet Companion</span>
          </h1>
          <p className="hero-subtext text-white/90 text-lg md:text-xl mb-8 leading-relaxed">
            Your trusted destination for pets, accessories, and pet care essentials. Welcome to PawHaven.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link href="/pets" className="btn-gradient px-8 py-4 text-lg rounded-xl inline-block">
              Browse Pets
            </Link>
            <Link
              href="#about"
              className="btn-outline bg-white/10 backdrop-blur-sm text-white border-white px-8 py-4 text-lg rounded-xl inline-block hover:bg-white hover:text-primary-green"
            >
              Learn More
            </Link>
          </div>
        </div>
      </section>

      <section className="my-20">
        <h2 className="text-3xl font-bold text-center mb-12">
          Start Your <span className="text-gradient">Shopping Journey</span>
        </h2>
        <div className="grid md:grid-cols-2 gap-8">
          <Link href="/pets" className="nav-button-card group">
            <div className="flex justify-center mb-4">
              <IconBadge icon={Dog} bgColor="bg-teal-50" iconColor="text-teal-600" size="xl" />
            </div>
            <h3 className="text-2xl font-bold mb-3 text-gray-900 group-hover:text-primary-green transition-colors">
              Pet Shopping
            </h3>
            <p className="text-gray-600 text-lg mb-4">Find Your Perfect Companion</p>
            <div className="inline-block bg-primary-green text-white px-6 py-2 rounded-full font-semibold group-hover:bg-primary-dark transition-colors">
              Explore Pets →
            </div>
          </Link>

          <Link href="/accessories" className="nav-button-card group">
            <div className="flex justify-center mb-4">
              <IconBadge icon={ShoppingBag} bgColor="bg-orange-50" iconColor="text-orange-600" size="xl" />
            </div>
            <h3 className="text-2xl font-bold mb-3 text-gray-900 group-hover:text-primary-green transition-colors">
              Accessories
            </h3>
            <p className="text-gray-600 text-lg mb-4">Everything Your Pet Deserves</p>
            <div className="inline-block bg-primary-green text-white px-6 py-2 rounded-full font-semibold group-hover:bg-primary-dark transition-colors">
              Shop Now →
            </div>
          </Link>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="my-20">
        <div className="grid md:grid-cols-2 gap-12 items-center bg-white/60 backdrop-blur-md rounded-3xl p-10 shadow-xl border border-white/80">
          <div className="space-y-6">
            <h2 className="text-4xl font-bold mb-6">
              About <span className="text-gradient">PawHaven</span>
            </h2>
            <p className="text-gray-700 text-lg leading-relaxed">
              PawHaven is built with love to connect pets with loving families. Our goal is to make pet care simple,
              transparent, and joyful for everyone.
            </p>
            <ul className="text-gray-700 space-y-4 text-lg">
              <li className="flex items-start gap-3">
                <Shield className="text-primary-green mt-1 flex-shrink-0" size={20} />
                <span>Trusted Pet Sellers & Breeders</span>
              </li>
              <li className="flex items-start gap-3">
                <Award className="text-primary-green mt-1 flex-shrink-0" size={20} />
                <span>Verified and Healthy Pets</span>
              </li>
              <li className="flex items-start gap-3">
                <Heart className="text-primary-green mt-1 flex-shrink-0" size={20} />
                <span>Complete Pet Care Solutions</span>
              </li>
            </ul>
          </div>
          <div className="flex justify-center items-center">
            <IconBadge
              icon={Dog}
              bgColor="bg-gradient-to-br from-teal-50 to-green-50"
              iconColor="text-teal-600"
              size="xl"
            />
          </div>
        </div>
      </section>

      <section className="my-20">
        <h2 className="text-3xl font-bold text-center mb-12">
          Shop by <span className="text-gradient">Category</span>
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
          <CategoryCard title="Pets" href="/pets" icon={Dog} bgColor="bg-teal-50" iconColor="text-teal-600" />
          <CategoryCard
            title="Accessories"
            href="/accessories"
            icon={ShoppingBag}
            bgColor="bg-orange-50"
            iconColor="text-orange-600"
          />
          <CategoryCard
            title="Pet Care"
            href="/pet-care"
            icon={Sparkles}
            bgColor="bg-blue-50"
            iconColor="text-blue-600"
          />
          <CategoryCard
            title="Supplements"
            href="/supplements"
            icon={Pill}
            bgColor="bg-rose-50"
            iconColor="text-rose-600"
          />
          <CategoryCard title="Food" href="/food" icon={Apple} bgColor="bg-purple-50" iconColor="text-purple-600" />
        </div>
      </section>

      <section className="my-20">
        <h2 className="text-3xl font-bold text-center mb-12">
          Pet Care <span className="text-gradient">Essentials</span>
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all">
            <div className="flex justify-center mb-4">
              <IconBadge icon={Sparkles} bgColor="bg-blue-50" iconColor="text-blue-600" size="lg" />
            </div>
            <h3 className="font-bold text-xl mb-3 text-center">Grooming</h3>
            <p className="text-gray-600 text-center">Premium shampoos, conditioners, and grooming tools</p>
          </div>
          <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all">
            <div className="flex justify-center mb-4">
              <IconBadge icon={Pill} bgColor="bg-rose-50" iconColor="text-rose-600" size="lg" />
            </div>
            <h3 className="font-bold text-xl mb-3 text-center">Health</h3>
            <p className="text-gray-600 text-center">Supplements and medicines for optimal pet health</p>
          </div>
          <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all">
            <div className="flex justify-center mb-4">
              <IconBadge icon={Package} bgColor="bg-amber-50" iconColor="text-amber-600" size="lg" />
            </div>
            <h3 className="font-bold text-xl mb-3 text-center">Nutrition</h3>
            <p className="text-gray-600 text-center">Quality food and treats for your furry friends</p>
          </div>
        </div>
      </section>

      {/* Trust & Safety Badges */}
      <section className="my-20">
        <div className="bg-gradient-to-br from-green-50 to-teal-50 rounded-3xl p-12">
          <h2 className="text-3xl font-bold text-center mb-12">
            Trust & <span className="text-gradient">Safety</span>
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="flex justify-center mb-4">
                <IconBadge icon={Shield} bgColor="bg-white" iconColor="text-primary-green" size="lg" />
              </div>
              <h3 className="font-bold text-lg mb-2">100% Secure</h3>
              <p className="text-gray-600">Safe payment gateway with Razorpay</p>
            </div>
            <div className="text-center">
              <div className="flex justify-center mb-4">
                <IconBadge icon={Award} bgColor="bg-white" iconColor="text-primary-green" size="lg" />
              </div>
              <h3 className="font-bold text-lg mb-2">Certified Breeders</h3>
              <p className="text-gray-600">All pets from verified sources</p>
            </div>
            <div className="text-center">
              <div className="flex justify-center mb-4">
                <IconBadge icon={Package} bgColor="bg-white" iconColor="text-primary-green" size="lg" />
              </div>
              <h3 className="font-bold text-lg mb-2">Safe Delivery</h3>
              <p className="text-gray-600">Secure packaging and handling</p>
            </div>
          </div>
        </div>
      </section>

      {/* Get Help Section */}
      <section id="help" className="my-20">
        <GetHelpForm />
      </section>

      {/* Help & Support Section */}
      <section className="my-20">
        <h2 className="text-3xl font-bold text-center mb-12">
          Help & <span className="text-gradient">Support</span>
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="feature-card">
            <div className="flex justify-center mb-4">
              <IconBadge icon={Headphones} bgColor="bg-teal-100" iconColor="text-teal-600" size="md" />
            </div>
            <h3 className="font-bold text-xl mb-2">24/7 Support</h3>
            <p className="text-gray-600">Round-the-clock assistance for all your pet care needs</p>
          </div>
          <div className="feature-card" style={{ animationDelay: "0.1s" }}>
            <div className="flex justify-center mb-4">
              <IconBadge icon={Shield} bgColor="bg-green-100" iconColor="text-green-600" size="md" />
            </div>
            <h3 className="font-bold text-xl mb-2">Health Guarantee</h3>
            <p className="text-gray-600">All pets come with health certificates and guarantees</p>
          </div>
          <div className="feature-card" style={{ animationDelay: "0.2s" }}>
            <div className="flex justify-center mb-4">
              <IconBadge icon={Heart} bgColor="bg-rose-100" iconColor="text-rose-600" size="md" />
            </div>
            <h3 className="font-bold text-xl mb-2">Post-Adoption Care</h3>
            <p className="text-gray-600">Continuous support and guidance after you bring your pet home</p>
          </div>
          <div className="feature-card" style={{ animationDelay: "0.3s" }}>
            <div className="flex justify-center mb-4">
              <IconBadge icon={Clock} bgColor="bg-orange-100" iconColor="text-orange-600" size="md" />
            </div>
            <h3 className="font-bold text-xl mb-2">Fast Delivery</h3>
            <p className="text-gray-600">Quick and safe delivery of products to your doorstep</p>
          </div>
        </div>
      </section>

      <section className="my-20">
        <h2 className="text-3xl font-bold text-center mb-12">
          Why Choose <span className="text-gradient">PawHaven</span>
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-gradient-to-br from-green-50 to-teal-50 rounded-3xl p-8 text-center">
            <div className="flex justify-center mb-4">
              <IconBadge icon={Award} bgColor="bg-white" iconColor="text-teal-600" size="lg" />
            </div>
            <h3 className="font-bold text-2xl mb-3">Quality Assured</h3>
            <p className="text-gray-700 leading-relaxed">
              Every pet and product goes through rigorous quality checks to ensure the best for your family
            </p>
          </div>
          <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-3xl p-8 text-center">
            <div className="flex justify-center mb-4">
              <IconBadge icon={Users} bgColor="bg-white" iconColor="text-orange-600" size="lg" />
            </div>
            <h3 className="font-bold text-2xl mb-3">Expert Guidance</h3>
            <p className="text-gray-700 leading-relaxed">
              Our team of pet experts is always ready to help you make the right choices for your pets
            </p>
          </div>
          <div className="bg-gradient-to-br from-rose-50 to-pink-50 rounded-3xl p-8 text-center">
            <div className="flex justify-center mb-4">
              <IconBadge icon={TrendingUp} bgColor="bg-white" iconColor="text-rose-600" size="lg" />
            </div>
            <h3 className="font-bold text-2xl mb-3">Trusted by Thousands</h3>
            <p className="text-gray-700 leading-relaxed">
              Join thousands of happy pet parents who trust PawHaven for all their pet needs
            </p>
          </div>
        </div>
      </section>
    </main>
  )
}
