"use client"

export function PetsCareGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="productsGrid">
      {/* Pet care products will be dynamically rendered here */}
    </div>
  )
}
