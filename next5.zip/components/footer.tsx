"use client"

import { Instagram, Youtube, Phone } from "lucide-react"
import { useEffect, useRef } from "react"

export function Footer() {
  const footerRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("footer-visible")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (footerRef.current) {
      observer.observe(footerRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <footer ref={footerRef} className="footer-glass text-center mt-28 footer-animate">
      <div className="mb-10 animate-footer-item" style={{ animationDelay: "0.1s" }}>
        <h3 className="text-4xl font-bold mb-8 text-white">
          Get in{" "}
          <span className="bg-gradient-to-r from-orange-400 to-coral-400 bg-clip-text text-transparent">Touch</span>
        </h3>
        <div className="flex flex-col sm:flex-row justify-center items-center gap-8 mb-10">
          <a
            href="tel:9263810276"
            className="footer-link flex items-center gap-3 text-gray-300 hover:text-orange-400 transition-colors text-lg font-medium group animate-footer-item"
            style={{ animationDelay: "0.2s" }}
          >
            <div className="p-3 bg-white/10 rounded-full group-hover:bg-orange-400/20 transition-colors">
              <Phone size={24} className="text-orange-400" />
            </div>
            9263810276
          </a>
          <a
            href="tel:6204408318"
            className="footer-link flex items-center gap-3 text-gray-300 hover:text-orange-400 transition-colors text-lg font-medium group animate-footer-item"
            style={{ animationDelay: "0.3s" }}
          >
            <div className="p-3 bg-white/10 rounded-full group-hover:bg-orange-400/20 transition-colors">
              <Phone size={24} className="text-orange-400" />
            </div>
            6204408318
          </a>
        </div>
      </div>

      <div className="flex justify-center gap-6 mb-12">
        <a
          href="https://www.instagram.com/dogify.world"
          target="_blank"
          rel="noopener noreferrer"
          className="social-link p-5 bg-white/10 rounded-2xl hover:bg-orange-400 hover:text-gray-900 transition-all duration-300 shadow-lg hover:shadow-2xl animate-footer-item"
          style={{ animationDelay: "0.4s" }}
          aria-label="Instagram"
        >
          <Instagram size={32} />
        </a>
        <a
          href="https://youtube.com/@dogifyworld"
          target="_blank"
          rel="noopener noreferrer"
          className="social-link p-5 bg-white/10 rounded-2xl hover:bg-orange-400 hover:text-gray-900 transition-all duration-300 shadow-lg hover:shadow-2xl animate-footer-item"
          style={{ animationDelay: "0.5s" }}
          aria-label="YouTube"
        >
          <Youtube size={32} />
        </a>
      </div>

      <div className="border-t border-white/10 pt-10 animate-footer-item" style={{ animationDelay: "0.6s" }}>
        <p className="text-gray-400 text-lg font-medium">
          © 2025{" "}
          <span className="bg-gradient-to-r from-orange-400 to-coral-400 bg-clip-text text-transparent font-bold">
            PawHaven
          </span>
          . Made with love for pet lovers
        </p>
      </div>
    </footer>
  )
}
