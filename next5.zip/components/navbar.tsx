"use client"

import Link from "next/link"
import Image from "next/image"
import { useState } from "react"
import { Menu, X } from "lucide-react"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  const handleLinkClick = () => {
    setIsOpen(false)
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-4 py-3">
      <div className="container mx-auto">
        <div className="navbar-glass rounded-2xl px-8 py-4">
          <div className="flex justify-between items-center">
            <Link href="/" className="flex items-center gap-3 group" onClick={handleLinkClick}>
              <div className="relative">
                <Image
                  src="/image/logo.jpg"
                  alt="PawHaven Logo"
                  width={50}
                  height={50}
                  className="rounded-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <span className="text-gradient text-2xl font-extrabold tracking-tight">PawHaven</span>
            </Link>

            <button
              className="lg:hidden text-gray-700 hover:text-primary-teal transition-colors p-2"
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle menu"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>

            <ul className={`nav-links ${isOpen ? "active" : ""}`}>
              <li>
                <Link href="/" className="nav-link" onClick={handleLinkClick}>
                  Home
                </Link>
              </li>
              <li>
                <Link href="/pets" className="nav-link" onClick={handleLinkClick}>
                  Pets
                </Link>
              </li>
              <li>
                <Link href="/accessories" className="nav-link" onClick={handleLinkClick}>
                  Accessories
                </Link>
              </li>
              <li>
                <Link href="/food" className="nav-link" onClick={handleLinkClick}>
                  Food
                </Link>
              </li>
              <li>
                <Link href="/pet-care" className="nav-link" onClick={handleLinkClick}>
                  Pet Care
                </Link>
              </li>
              <li>
                <Link href="/supplements" className="nav-link" onClick={handleLinkClick}>
                  Supplements
                </Link>
              </li>
              <li>
                <Link href="/#about" className="nav-link" onClick={handleLinkClick}>
                  About
                </Link>
              </li>
              <li>
                <Link href="/#help" className="nav-link" onClick={handleLinkClick}>
                  Get Help
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
  )
}
