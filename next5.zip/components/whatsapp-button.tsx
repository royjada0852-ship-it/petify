"use client"

import { MessageCircle } from "lucide-react"

export function WhatsAppButton() {
  const handleClick = () => {
    const message = "Hello Dogify! I want to chat."
    const whatsappNumber = "919263810276"
    const whatsappURL = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`
    window.open(whatsappURL, "_blank")
  }

  return (
    <button
      onClick={handleClick}
      className="whatsapp-float"
      title="Chat with Dogify on WhatsApp"
      aria-label="Chat with Dogify on WhatsApp"
    >
      <MessageCircle size={28} />
      <span className="whatsapp-badge">Chat</span>
    </button>
  )
}
